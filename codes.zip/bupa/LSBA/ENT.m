function [ecs]=ENT(data)
[r,c]=size(data);

if (r>1)&&(c>1)
for j=1:c
    temp=data(:,j);
    data(:,j)=(data(:,j)-min(temp))/(max(temp)-min(temp)); 
end

fc=0;
for j=1:c
    fc=fc+std(data(:,j));
end
fc=fc/c;
ecs=fc;
else
    ecs=999999;
end

end