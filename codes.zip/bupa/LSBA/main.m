clear;clc;
set(0,'RecursionLimit',100000000)
result=[];
alpha=1.2;
%1 0.01 70%
delta=0.8;
Thc=0.005; confidence=0.65;


wholeresult=[];
data=load('bupa.txt');
Y=data(:,end);
Y(find(Y==2))=-1;
data=[Y data(:,1:end-1)];

% data(:,2:end)=suoyouliezuidazuixiao(data(:,2:end));


n=size(data,1);
pn=floor(0.1*n);
index=zeros(10,pn);
whole=1:n;
wrongindex=[];

% for i=1:10
%     index100=randperm(length(whole),pn);
%     index(i,:)=whole(index100);
%     whole=setdiff(whole,index(i,:));
% end
load index
for k=1:10
        testindex=index(k,:);
        tdata=data(testindex,:);
        traindata=data(setdiff(1:n,testindex),:);
        testlabel=tdata(:,1);
        testdata=tdata(:,2:end);
        b=-1; m=1; 

        fdata=traindata(:,2:end);
        gyhdata=traindata;
        gyhdata(:,2:end)=suoyouliezuidazuixiao(gyhdata(:,2:end));
        [brules,mrules,zeroindex]=searchrulesfromwholedata(fdata,gyhdata,delta,alpha,Thc,confidence);
 
        
        if ~isempty(brules)&&~isempty(mrules)
            brules
            mrules
            [strongclassifier,W]=adaboost(brules,mrules,traindata);     
            %improve the rules
            [brules2,mrules2]=secondsearchimprovebicluster(traindata,brules,mrules,strongclassifier,delta);
        else
            brules2=brules;
            mrules2=mrules;
        end
        %in above step, brules and mrules are better changed
        %in following step, zeroindex should be trained once again by increasing delta.
        %combine the new rules found from zerorules to brule2 and mrules2
        [brules2,mrules2]=retraindeletedbiclusters(zeroindex,brules2,mrules2,delta,traindata,confidence,alpha);
        
  
            brules2
            mrules2
        [strongclassifier2,W2]=adaboost(brules,mrules,traindata);
        testresult2=[];
        for i=1:size(testdata,1)
           testresult2=[testresult2;  predictlabel(strongclassifier2,testdata(i,:))];        
        end
        testresult2=sign(testresult2);
%         diff2=testlabel-testresult2;
%         error=length(find(diff2~=0))/length(diff2);
%         result=[result; [1-error]];

correctClass=classtransform(testlabel);
estimatClass=classtransform(testresult2);

classifstat=class_stats(correctClass, estimatClass)
wholeresult=[wholeresult; [classifstat.accuracy   classifstat.precision  classifstat.recall  classifstat.fmeasure  classifstat.auc ... 
                           classifstat.matthewscorrcoeff  classifstat.cohenskappa  classifstat.mutual_information
                          ] ];
end

  disp(['accuracy-mean = ' num2str( mean(wholeresult(:,1))), ' accuracy-std = ' num2str(std(wholeresult(:,1))) ]);
%   disp(['precision-mean = ' num2str( mean(wholeresult(:,2))), ' precision-std = ' num2str(std(wholeresult(:,2))) ]);
%   disp(['recall-mean = ' num2str( mean(wholeresult(:,3))), ' recall-std = ' num2str(std(wholeresult(:,3))) ]);
%   disp(['fmeasure-mean = ' num2str( mean(wholeresult(:,4))), ' fmeasure-std = ' num2str(std(wholeresult(:,4))) ]);
  disp(['auc-mean = ' num2str( mean(wholeresult(:,5))), ' auc-std = ' num2str(std(wholeresult(:,5)) )]);
 
  disp(['matthewscorrcoeff-mean = ' num2str( mean(wholeresult(:,6))), ' matthewscorrcoeff-std = ' num2str(std(wholeresult(:,6)) )]);
  disp(['cohenskappa-mean = ' num2str( mean(wholeresult(:,7))), ' cohenskappa-std = ' num2str(std(wholeresult(:,7)) )]);
%    disp(['mutual_information-mean = ' num2str( mean(wholeresult(:,8))), ' mutual_information-std = ' num2str(std(wholeresult(:,8)) )]);









