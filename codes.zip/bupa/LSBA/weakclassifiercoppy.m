function [label]=weakclassifiercoppy(rb,rm,testsample)

    bn=rb(2);
    bpos=rb(3:bn+2);
    bfeatures=rb(bn+3:2*bn+2);
    Db=power(norm(bfeatures-testsample(bpos)),2)/bn;

    mn=rm(2);
    mpos=rm(3:mn+2);
    mfeatures=rm(mn+3:2*mn+2);
    Dm=power(norm(mfeatures-testsample(mpos)),2)/mn;

    if Db<Dm
        label=-1;
    else
        label=1;
    end

end