


data=load('bupa.txt');
label=data(:,end);
data=[label data(:,1:end-1)];

n=size(data,1);
pn=floor(0.1*n);
index=zeros(10,pn);
whole=1:n;
accuracy=[];
% for i=1:10
%          index100=randperm(length(whole),pn);
%           index(i,:)=whole(index100);
%     whole=setdiff(whole,index(i,:));
% end
load index
wholeresult=[];
for k=1:10
        testindex=index(k,:);
        tdata=data(testindex,:);
        testlabel=tdata(:,1);
        testdata=tdata(:,2:end);

        traindata=data(setdiff(1:n,testindex),:);
      [D, W] = MBLDA(traindata(:,2:end), traindata(:,1));
      Trainresult=traindata(:,2:end)*W;
      Testresult=testdata*W;
      
      predicttestlabel=knnzjl(Trainresult,traindata(:,1),Testresult);
%       cha=predicttestlabel-testlabel';
correctClass=classtransform(testlabel');
estimatClass=classtransform(predicttestlabel);

classifstat=class_stats(correctClass, estimatClass)
wholeresult=[wholeresult; [classifstat.accuracy   classifstat.precision  classifstat.recall  classifstat.fmeasure  classifstat.auc ... 
                           classifstat.matthewscorrcoeff  classifstat.cohenskappa  classifstat.mutual_information
                          ] ];
end

  disp(['accuracy-mean = ' num2str( mean(wholeresult(:,1))), ' accuracy-std = ' num2str(std(wholeresult(:,1))) ]);
%   disp(['precision-mean = ' num2str( mean(wholeresult(:,2))), ' precision-std = ' num2str(std(wholeresult(:,2))) ]);
%   disp(['recall-mean = ' num2str( mean(wholeresult(:,3))), ' recall-std = ' num2str(std(wholeresult(:,3))) ]);
%   disp(['fmeasure-mean = ' num2str( mean(wholeresult(:,4))), ' fmeasure-std = ' num2str(std(wholeresult(:,4))) ]);
  disp(['auc-mean = ' num2str( mean(wholeresult(:,5))), ' auc-std = ' num2str(std(wholeresult(:,5)) )]);
 
  disp(['matthewscorrcoeff-mean = ' num2str( mean(wholeresult(:,6))), ' matthewscorrcoeff-std = ' num2str(std(wholeresult(:,6)) )]);
  disp(['cohenskappa-mean = ' num2str( mean(wholeresult(:,7))), ' cohenskappa-std = ' num2str(std(wholeresult(:,7)) )]);
%    disp(['mutual_information-mean = ' num2str( mean(wholeresult(:,8))), ' mutual_information-std = ' num2str(std(wholeresult(:,8)) )]);






