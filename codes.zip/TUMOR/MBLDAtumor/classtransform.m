function transformedlabel=classtransform(label)

kinds=unique(label);
label(find(label==kinds(1)))=0;

if length(kinds)>1
label(find(label==kinds(2)))=1;
end
transformedlabel=label;
end