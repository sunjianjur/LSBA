function predicttestlabel=knnzjl(Trainresult,Trainlabel,Testresult)
predicttestlabel=[];

for i=1:size(Testresult,1)
    distance=[];
    for j=1:length(Trainlabel)
         distance=[distance norm((Testresult(i,:)-Trainresult(j,:)),2)/length(Testresult(i,:))];
    end
    [~,minpos]=min(distance);
    predicttestlabel=[predicttestlabel Trainlabel(minpos)];
end

end