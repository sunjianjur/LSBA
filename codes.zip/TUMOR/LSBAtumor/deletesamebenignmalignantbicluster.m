function [brules,mrules]=deletesamebenignmalignantbicluster(brules,mrules)
% rule=[length(r) length(c) c  mean(data(r,c)) r ]
sameindex=[];

for i=1:size(brules,2)
    br=brules(i).real;
    bclength=br(2);
    bcindex=br(3:(2+bclength));
    bcvalue=br((3+bclength):(2+2*bclength));
    for j=1:size(mrules,2)
         bm=mrules(j).real; 
         mclength=bm(2);
         mcindex=bm(3:(2+mclength));  
         mcvalue=bm((3+mclength):(2+2*mclength));
         %if both cindex and cvalues are same,then delete both biclusters 
         if (length(bcindex)==length(mcindex))
             if sum(abs(bcvalue-mcvalue))==0
                sameindex=[sameindex; [i j]];
             end
         end
    end    
end

if size(sameindex,1)>0
    brules(unique(sameindex(:,1)))=[];
    mrules(unique(sameindex(:,2)))=[];
end

end