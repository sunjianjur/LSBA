function [brules,mrules]=secondsearchimprovegood(traindata,brules,mrules,strongclassifier,delta)
%���˰�����ǿ�������е�˫���࣬�����Ķ�Ҫ����ѵ��
posweight=strongclassifier.w;
pos=[];weight=[];
for i=1:size(posweight,2)
    pos=[pos posweight(i).c]; 
    weight=[weight posweight(i).w];  
end

nm=size(mrules,2);
lessindex=find(weight<mean(weight));
badrulepos=pos(lessindex);
[bbad,mbad]=findrc(badrulepos,nm);
bbad=unique(bbad);
mbad=unique(mbad);

data=traindata(:,2:end);
label=traindata(:,1);
labelb=find(label==-1);
labelm=find(label==1);
bdata=data(labelb,:); 
mdata=data(labelm,:);

for i=1:length(bbad)
  rule=brules(bbad(i)).real;
  brules(bbad(i)).real=lessdeltatrain(bdata,rule,delta);
end

for i=1:length(mbad)
  rule=mrules(mbad(i)).real;
  mrules(mbad(i)).real=lessdeltatrain(mdata,rule,delta);
end
   
end