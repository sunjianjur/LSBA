function rule=lessdeltatrain(data,rule,delta)
%rule=[length(r) length(c) c  mean(data(r,c)) r];  
% 0.9 0.8 0.7 0.6 0.5 five values should be tested.
%delete one row/column each time
%if the number of rows and columns is small, then set rule as empty [].
newdelta=0.2*delta;

nr=rule(1);nc=rule(2);
c=rule(3:2+nc);
r=rule(2+2*nc+1:2+2*nc+nr);

entropy=ENT(data(r,c));


%first delete, then add one row/column
% while (entropy>newdelta)&&(length(r)>5)&&(length(c)>3)
while (entropy>newdelta)
    remainr=setdiff(1:size(data,1),r);
    ER=[];
    for i=1:length(remainr)
      tempr=[r remainr(i)];
      ER=[ER ENT(data(tempr,c))];
    end
    [minr,minposr]=min(ER);
   
    remainc=setdiff(1:size(data,2),c);
    EC=[];
    for i=1:length(remainc)
      tempc=[c remainc(i)];
      EC=[EC ENT(data(r,tempc))];
    end
    [minc,minposc]=min(EC);  
    if minr<=minc
        r=[r,remainr(minposr)];
    else
        c=[c,remainc(minposc)];
    end
    
    entropy=ENT(data(r,c));
end

rule=[length(r) length(c) c  mean(data(r,c)) r];  

% if (entropy>newdelta)||(length(r)<5)||(length(c)<3)
%     rule=[];
% else
%     rule=[length(r) length(c) c  mean(data(r,c)) r];  
% end

end