function rules=deleteoverlap(rules)
 % rule=[length(r) length(c) c  mean(data(r,c)) r ];

 n=size(rules,2);
 
 index=[];
 
 for i=1:(n-1)
      inr=rules(i).real(1);
      inc=rules(i).real(2);
      ic=rules(i).real(3:(2+inc));
      ir=rules(i).real((3+2*inc):(2+inr+2*inc));
     for j=(i+1):n
          jnr=rules(j).real(1);
          jnc=rules(j).real(2);
          jc=rules(j).real(3:(2+jnc));
          jr=rules(j).real((3+2*jnc):(2+jnr+2*jnc));

          recovery=(length(intersect(ic,jc))+length(intersect(jr,ir)))/(length(union(ic,jc))+length(union(jr,ir)));
          if recovery>0.8
             index=[index;[i j]];
          end
     end
 end
 
 all=[];
  for i=1:size(index,1)
     pos=index(i,:);
     one=pos(1);
     two=pos(2);
     vone=rules(one).real(1)*rules(one).real(2);
     vtwo=rules(two).real(1)*rules(two).real(2);
     
     if  vone>=vtwo
          all=[all two];
     elseif vone<vtwo
         all=[all one];
     end
  end
 all=unique(all);
 all=sort(all);
 
rules(all)=[];
 
end
 
