function [bgood,mgood]=findrc(pos,m)
bgood=[];
mgood=[];

for i=1:length(pos)
  
       mtemp=mod(pos(i),m);
       btemp=floor(pos(i)/m);
       if mtemp==0;
           mtemp=m;
           btemp=btemp-1;
       end      
 
    bgood=[bgood;btemp+1];
    mgood=[mgood;mtemp];
end

end