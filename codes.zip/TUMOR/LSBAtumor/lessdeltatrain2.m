function rule=lessdeltatrain2(data,rule,delta)

newdelta=0.2*delta;
nr=rule(1);nc=rule(2);
c=rule(3:2+nc);
r=rule(2+2*nc+1:2+2*nc+nr);
entropy=ENT(data(r,c));
    lengthr=length(r);

if entropy<0.5*delta
  data2=data(r,c);
  deletedrow=[];
  for i=1:length(c)
      tempdata=data2(:,i);
      b=tabulate(tempdata);
    d=b(:,3);
    deletedrowindex=find(d<0.05*sum(d));
    deletedrowvalue=b(deletedrowindex,1);
     for k=1:length(deletedrowvalue)
      deletedrow=[deletedrow find(tempdata==deletedrowvalue(k))'];   
     end
  end
  r(unique(deletedrow))=[];
else
    tiji=[10000000 length(r)*length(c)];
   while(entropy>newdelta)&&(length(r)>4)&&(length(c)>3&&(tiji(end)<tiji(end-1))) 
 
     r1=length(r);
    c1=length(c);
    ER=[];
    for i=1:length(r)
        tempr=setdiff(r,r(i));
         ER=[ER ENT(data(tempr,c))];
    end    
    if r1<0.8*lengthr
        [mr,mrp]=min(ER)
        r=setdiff(r,r(mrp));
    else    
        averageER=mean(ER);
        [~,pos]=sort(ER);
        spos=pos(1:round(0.1*length(r)));%10%��С��λ��
        finalpos=[];
        for j=1:length(spos)
             if ER(spos(j))<averageER
                 finalpos=[finalpos spos(j)];
             end
        end
        r=setdiff(r,r(finalpos));
    end
    entropy=ENT(data(r,c));
    tiji=[tiji length(r)*length(c)];
   end   
    while (entropy<newdelta)&&(length(r)>=4)&&(length(c)>=3)
        ER=[];
        for i=1:length(r)
            tempr=setdiff(r,r(i));
             ER=[ER ENT(data(tempr,c))];
        end    
            [mr,mrp]=min(ER);

         EC=[];
        for i=1:length(c)
           EC=[EC ENT(data(r,setdiff(c,c(i))))];
        end
        [mc,mcp]=min(EC);

         if mr<=mc
            r=setdiff(r,r(mrp));
         else
             c=setdiff(c,c(mcp));
         end

        entropy=ENT(data(r,c));
    end
end

rule=[length(r) length(c) c  mean(data(r,c)) r ENT(data(r,c))];  


end