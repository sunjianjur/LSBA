function mm = suoyouliezuidazuixiao(datamatrix)
    
     a=size(datamatrix,2);
     for i=1:a
         temp=datamatrix(:,i);
        xiao=min(temp);
        da=max(temp);
        datamatrix(:,i)=(temp-xiao)/(da-xiao);
     end
     mm=datamatrix;
     
end