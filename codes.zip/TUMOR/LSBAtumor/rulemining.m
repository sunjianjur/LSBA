function [rule]=rulemining(data,r,c,wholer,wholec,delta)
entropy=ENT(data(r,c));
allcolumnnumber=length(c);
%delete row/column
while(entropy>delta)&&(length(r)>4)&&(length(c)>3)
    %each time updata r,c   
 %�����д�������ֻ������ɾ����û��singleɾ��   
    r1=length(r);
    c1=length(c);
    ER=[];
    for i=1:length(r)
        tempr=setdiff(r,r(i));
         ER=[ER ENT(data(tempr,c))];
    end    
    if r1<0.3*length(wholer)
        [mr,mrp]=min(ER);
        r=setdiff(r,r(mrp));
    else    
        averageER=mean(ER);
        [~,pos]=sort(ER);
        spos=pos(1:round(0.1*length(r)));%10%��С��λ��
        finalpos=[];
        for j=1:length(spos)
             if ER(spos(j))<averageER
                 finalpos=[finalpos spos(j)];
             end
        end
        r=setdiff(r,r(finalpos));
    end
    entropy=ENT(data(r,c));
%column adopts the same strategy as CC algorithm   
        EC=[];
        for i=1:length(c)
           EC=[EC ENT(data(r,setdiff(c,c(i))))];
        end
         if length(c)<allcolumnnumber/2
             [mc,mcp]=min(EC);
             c=setdiff(c,c(mcp));
         else
            [~,pcd]=find(EC>=1.05*entropy);
            pc=c(pcd);  
            c=setdiff(c,pc);
         end
    entropy=ENT(data(r,c));
end

%add row/column
r=r';
% entropy2=0;
% while(entropy2<=delta)
%     r2=length(r);
%     c2=length(c);
%     ER=[];EC=[];
%     
%     remainr=setdiff(wholer,r);
%     for i=1:length(remainr)
%        tempr=[r remainr(i)]; 
%        ER=[ER ENT(data(tempr,c))];
%     end
%     [mr,mrp]=min(ER);
%     
%     remainc=setdiff(wholec,c);
%      for i=1:length(remainc)
%        tempc=[c remainc(i)]; 
%        EC=[EC ENT(data(r,tempc))];
%     end
%     [mc,mcp]=min(EC);
%     
% %�����д��������Ǽ�ʹ����delta��Ҳ����롣��ȷ�������ǼӺ�С��delta�żӡ�
%   if min(mr,mc)<=delta
%     if mr<=mc
%         r=[r remainr(mrp)];
%     else
%         c=[c remainc(mcp)];
%     end
%      entropy2=ENT(data(r,c));
%   else
%      break; 
%   end
%     
% end    

%    data2=data(r,c);
%   deletedrow=[];
%   for i=1:length(c)
%       tempdata=data2(:,i);
%       b=tabulate(tempdata);
% d=b(:,3);
% deletedrowindex=find(d<0.05*sum(d));
% deletedrowvalue=b(deletedrowindex,1);
%      for k=1:length(deletedrowvalue)
%       deletedrow=[deletedrow find(tempdata==deletedrowvalue(k))'];   
%      end
%   end
%   r(unique(deletedrow))=[];



   if ENT(data(r,c))<=delta    
       rule=[length(r) length(c) c  mean(data(r,c)) r ENT(data(r,c))];
   else
       rule=[];
   end

%    if ENT(data(r,c))<=delta
%        sublabel=label(r);
%        nb=0;nm=0;
%        for i=1:length(r)
%             if sublabel==1
%                 nm=nm+1;
%             else
%                 nb=nb+1;
%             end
%        end
%        
%        if (nb>nm)&&((nb/(nb+nm))>0.65)
%            biaoqian=1;              
%            rule=[biaoqian length(c) mean(data(r,c))];
%        elseif (nb<nm)&&((nm/(nb+nm))>0.65)
%            biaoqian=-1;              
%            rule=[biaoqian length(c) mean(data(r,c))];
%        end     
%    else
%        rule=[];
%    end
   
end