function  [out,usedrow]=extractclusters(one,two,Zsmall,len)
    usedrow=[];
    out=[];
    if one<=len
       out=[out one];
    else
       rownum=chazhao(Zsmall,one);
       [value,row]=extractclusters(Zsmall(rownum,2), Zsmall(rownum,3),Zsmall,len);
       usedrow=[usedrow rownum row];
       out=[out value]; 
    end
    
    if two<=len
       out=[out two];
    else
       rownum=chazhao(Zsmall,two);
      [value,row]=extractclusters(Zsmall(rownum,2), Zsmall(rownum,3),Zsmall,len);
           usedrow=[usedrow rownum row];
       out=[out value]; 
    end

end