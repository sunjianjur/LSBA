function [predictlabel]=predictlabel(strongclassifier,sample)

wc=strongclassifier.c;
posweight=strongclassifier.w;

pos=[];
weight=[];
for i=1:size(posweight,2)
    pos=[pos posweight(i).c]; 
    weight=[weight posweight(i).w]; 
end

predictlabel=0;
for i=1:size(posweight,2)
      predictlabel=predictlabel+weight(i)*weakclassifier(wc(pos(i)).b,wc(pos(i)).m,sample);    
end

end