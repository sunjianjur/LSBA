function [r,c,biaoqian]=changeconfidencetodeterminebiaoqian(data,r,c,label,confidence)

    sublable=label(r);
    nb=length(find(sublable==-1));
    nm=length(find(sublable==1));
      
if nb>nm
    biaoqian=-1;
    %delete the biggest reducedrownumber rows
    reducedrownumber=ceil((nb+nm)-(nb/confidence));
     ER=[];
     rmin=r(find(sublable==1));
    for i=1:length(rmin)
        tempr=setdiff(r,rmin(i));
         ER=[ER ENT(data(tempr,c))];
    end    
    [v,p]=sort(ER);
    r=setdiff(r,rmin(p(1:reducedrownumber)));  
else
    biaoqian=1;
    reducedrownumber=ceil((nm+nb)-(nm/confidence));
     ER=[];
     rmin=r(find(sublable==-1));
    for i=1:length(rmin)
        tempr=setdiff(r,rmin(i));
         ER=[ER ENT(data(tempr,c))];
    end    
    [v,p]=sort(ER);
    r=setdiff(r,rmin(p(1:reducedrownumber)));  
end

end