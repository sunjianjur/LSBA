function [brules,mrules]=secondsearchimprovebicluster(traindata,brules,mrules,strongclassifier,delta)
%���˰�����ǿ�������е�˫���࣬�����Ķ�Ҫ����ѵ��
posweight=strongclassifier.w;
pos=[];weight=[];
for i=1:size(posweight,2)
    pos=[pos posweight(i).c];   
end

nb=size(brules,2);
nm=size(mrules,2);
[bgood,mgood]=findrc(pos,nm);
bgood=unique(bgood);
mgood=unique(mgood);

bbad=setdiff(1:nb,bgood);
mbad=setdiff(1:nm,mgood);

data=traindata(:,2:end);




for i=1:length(bbad)
  rule=brules(bbad(i)).real;
%   brules(bbad(i)).real=lessdeltatrain(bdata,rule,delta);
 brules(bbad(i)).real=lessdeltatrain2(data,rule,delta); 
end

for i=1:length(mbad)
  rule=mrules(mbad(i)).real;
%   mrules(mbad(i)).real=lessdeltatrain(mdata,rule,delta);
mrules(mbad(i)).real=lessdeltatrain2(data,rule,delta);
end
   
end