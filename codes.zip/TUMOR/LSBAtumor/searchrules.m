function [rule]=searchrules(alldata,bm,delta,alpha)

label=alldata(:,1);
benignpos= find(label==bm);
traindata=alldata(benignpos,:);
data=traindata(:,2:end);

[r,c]=size(data);
wholer=1:r;
wholec=1:c;


n=0;
for i=1:c
   di=data(:,i);
   mlgs=unique(di);
   for j=1:length(mlgs)       
      pr=find(di==mlgs(j));
      if length(pr)>3
          n=n+1;
          rowindex(n).real=pr;
          rowindex(n).image=[i,j];
      end
   end
end

j=0;
for i=1:n
   rindex=rowindex(i).real;
   cindex=1:c;
%    temp=rulemining(data,rindex,cindex,wholer,wholec,delta);
 temp=ruleminingcc(data,rindex,cindex,wholer,wholec,delta,alpha); 
   if ~isempty(temp)
       j=j+1;
       rule(j).real=temp;
       rule(j).image=j;
   end   
end

end