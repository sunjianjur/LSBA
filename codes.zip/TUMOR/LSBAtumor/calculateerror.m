function [error,pos]=calculateerror(wc,traindata,W)

groundtruth=traindata(:,1);
data=traindata(:,2:end);

predictlabel=[];
for i=1:size(data,1)
    predictlabel=[predictlabel; weakclassifier(wc.b,wc.m,data(i,:))];
end

difference=groundtruth-predictlabel;
pos=find(difference~=0);

error=sum(W(pos));

end